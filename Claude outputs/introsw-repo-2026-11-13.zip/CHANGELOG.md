# Changelog

## 2026-11-13 (The Family Next Door, redesign)
- Story: a 30-day deadline (the city will pave the empty lot unless the neighbors win a town hall) and two twists found only through research: a construction truck dumps the trash at 2 a.m., and Xiao Yu skips school because he gets up every night to help Grandpa, who falls in the dark hallway.
- Act 1 is now the last five days of summer: six ideas, time for five, in any order. It ends with Xiao Yu missing in the dark lane (flashlight search).
- Library: find the five research books among junk books. Exams are card-sort mini-games (BSW; MSW adds putting the six steps in order); missed books get a ! again.
- Act 3: four investigations in any order, each costing days: interviews (trust meter), night watch (counting what passes), survey, literature (source detective). Each success is an evidence card.
- Town hall mini-game: answer four claims with evidence cards. Three endings (4 points, 2-3, 0-1), with a choice to replay the 30 days.
- Mini-games live in `games/family-next-door/minigames.js`. Time-jump cards cut from about 15 to 5 per playthrough.
- Engine: `@mini name var [arg]` runs a game's own mini-game; `@add var n`. Storm Creek and Tuesday Club checked.

## 2026-11-12 (The Family Next Door)
- New game: **The Family Next Door 隔壁那一家** (`games/family-next-door/`), a story adventure on social work research, played in pairs on one phone.
- Act 1: Ah-Zhe tries six ideas to help the Chen family and Peace Lane, each from a way of knowing that skips checking (intuition, authority, tradition, common sense, logic, the halo effect). Each one fails, then a discussion pause.
- Act 2: in the library he reads five books and takes a one-try BSW exam (5 questions, all must be right), then five more books and an MSW exam. Exam options are shuffled, nothing is revealed during the exam, and a fail lists the missed questions and puts a ! back on the books to reread.
- Act 3: he returns as a social worker and follows the research steps (question, consent, interviews, literature review, mixed-methods survey, analysis, evidence-based plan with the neighbors, evaluation with a comparison group). Wrong choices show GUESSING AGAIN and return to that step. 23 notebook terms.
- Jump codes on the title screen for a new device: LIBRARY, MASTER, HOMECOMING.
- Opening password screen (like Storm Creek): password **RCT**, set in `GATE_PASSWORD` in `index.html`. Once entered, a device remembers it.
- Engine: quizzes can be exam questions (`exam: 'varName'`: one try, shuffled, sets `ok_<id>` and a score); scripts can place sprites from a game's own `extra.png` (`X:n`); end-screen text can show script variables; test-mode hooks `examWrong` and `choicePick`. Storm Creek and Tuesday Club checked.

## 2026-11-10 (Which Hat?)
- New game: **Which Hat? 哪一頂帽子？** (`games/which-hat/`), a supervision role-play for the Social Work Administration unit (textbook Ch. 8), played by groups of 4 on one phone or tablet.
- Opens by introducing the four functions of supervision as colored hats with a memory symbol each: Educational 教育性 (teal, lightbulb, "Learn"), Administrative 行政性 (orange, clipboard, "Rules"), Supportive 支持性 (green, heart, "Feelings"), Mediating 調解性 (purple, bridge, "Bridge"), with the meaning and the question each hat asks.
- Setup: the group enters four names (Supervisor, Worker, Observer 1, Observer 2), then accepts or edits each name before starting.
- Each round: the supervisor gets a suggested opener (shuffle for another), the worker reads a random scenario aloud, a 3-minute timer runs with the four hats shown as reminders (pause, +30 s, finish early), the two observers decide together and tick the hats they saw, and the game shows suggested hats with a short reason. Roles then rotate (Supervisor → Worker → Observer → Supervisor), four rounds in all, so everyone supervises once. An end summary lists every round.
- 24 bilingual scenarios; none repeat within a game, and a device does not repeat them across games until the pool runs low. Progress is saved on the device ("Continue game" after a reload); the screen stays awake during the timer.
- Touch first; keyboard for the projector demo (Enter/Space, ← →, 1–4 to tick hats, P pause, M mute). Sounds are generated in the browser. No 8BitDo support.

## 2026-10-27 (Key Term Tycoon, mini-games)
- Landing on your **own** term starts a mini-game, picked at random: **Stop the Meter** (press Ⓐ when the swinging needle is in the green zone; 2 hits out of 3) or **Arrow Echo** (watch and hear 4–6 arrows, then repeat them on the D-pad or arrow keys). Each has its own chiptune loop generated in the browser.
- Win: that term's rent doubles (×2 → ×4 → ×8, capped at ×8); the games get harder as the multiplier rises. Lose: nothing happens. Ⓑ skips the mini-game. The multiplier shows on the board ("RENT ×4") and is lost if the term goes back to the bank.
- Rent questions: a correct answer now **halves** the rent instead of cancelling it.
- The 8BitDo D-pad is read for Arrow Echo (standard buttons, stick or hat switch). Correct / Incorrect remain keyboard-only.

## 2026-10-26 (Key Term Tycoon, update)
- The board now fills the whole screen with larger text. Team cash, the clock and the last roll sit in a small bar inside the board; the event list is a pop-up (L).
- Dice fix: the dice faces were blank (their padding was sized from the whole centre area). The last roll now also stays visible in the top bar.
- Each team gets a random shape (circle, triangle, square, diamond, star or hexagon). Tokens are the team's shape, and the shape appears just inside the board next to every term the team owns.
- Correct / Incorrect can only be chosen on the teacher's keyboard (Enter / Backspace) or mouse; the 8BitDo is ignored on those screens. The controller still rolls, buys, passes and continues.
- Controller loop made robust (an error can no longer stop it); controller status and button setup (C) are in the small toolbar.

## 2026-10-26 (Key Term Tycoon)
- New game: **Key Term Tycoon 關鍵詞大亨** (`games/term-tycoon/`), a midterm review board game played on the projector by 2–4 teams. 28-square board with 20 key terms from the study sheet in six districts (Basics, History, Systems, Group Work, Community Work, Case Management), 4 Pop Quiz squares, Start, Detention, Coffee Break and Go to Detention.
- Buying a term = explaining it (exam prompt 1). Landing on another team's term = answer a question within a countdown (default 10 s) or pay rent; a whole district doubles the rent. Pop Quiz cards draw from all six exam prompts and every study-sheet term. The teacher judges every answer with Correct / Incorrect (Ⓐ / Ⓑ); the game handles cash, rent, Start money, doubles, Detention, bankruptcy and the winner.
- Time limit (default 35 min): when time runs out the round finishes and the highest total (cash + terms) wins. Undo, pause, resume after a page reload, keyboard and one 8BitDo (A = button 1, B = button 0; changeable on the setup screen).
- The whole page is **encrypted** (AES-GCM, PBKDF2-SHA256): without the password the published file can't be read. The readable source, password and `build.py` are in the teacher folder, not in this repo.

## 2026-10-26 (later)
- Term Duel: added a **Community Work 社區工作** topic (10 terms: community, NBCD, ABCD, cycle of dependency, community participation, community self-determination, community capacity building, locality development, social planning, social action). Direct link: `games/term-duel/#community-work`.
- Removed **Term Flip** from the site.

## 2026-10-26
- **Storm Over Clear Creek, update.** Only Xiao An walks around now (no second figure following the player): the student meets her at the bus stop, she says "follow me," and the view switches to hers. The tunnel on typhoon night (Path 2) is now a timed maze in the dark: only a lantern circle around the player is lit, and rising water gives a time limit (about 32 s; the fastest route takes about 16 s). Students must find the boy and leave by the far exit; if time runs out, the maze restarts from the entrance (after two failures, Mrs. Lin gives a small hint). The maze is the same every time, so students learn it. Change `MAZE_SLACK` in `tools/story.py` to make it easier or harder. After Grandma Chen is found, the group returns to the activity center automatically. The NBCD quiz no longer refers to the textbook.
- Shared engine: `@light r | off` (lantern circle in the dark) and `@timer seconds label | off` (countdown clock, paused during dialogue).
- **Storm Over Clear Creek, version 2.** The game now opens with a password screen (the password is `GATE_PASSWORD` near the bottom of `games/storm-creek/index.html`). It is a simple check, not encryption.
- New opening: a lecture hall with 60 students. The teacher lectures in English, the students struggle and fall asleep, a typhoon cuts the power, and the player wakes up in Clear Creek as a student observer. Only Xiao An, the social worker, can see the player; she now walks one step behind the player.
- **Path 1 (need-based):** Xiao An follows the county report, surveys needs, waits for the outside rescue team on typhoon night, and the aid pours in (meal delivery, nursing team, shuttle, supplies; the residents see the benefits). One year later the funding ends and nothing has grown: the nurse stopped caring for neighbours, Lantern Night is gone, the co-op dissolved, Grandma Chen is in an institution. New notebook term: cycle of dependency (依賴循環). Then a discussion pause that needs a password (`DISCUSS_PASSWORD` in `tools/story.py`, also a jump code on the title screen).
- **Path 2 (asset-based):** time rewinds and the player advises Xiao An at five decisions (first step, Mrs. Lin, typhoon night, who decides, the county's offer to take over everything). A wrong choice shows GAME OVER and "Try Again" restarts Path 2. The town hall and Lantern Night stay, then the lights come back on in the lecture hall and a final discussion question appears.
- The story, passwords and discussion questions are in `games/storm-creek/tools/story.py`; run `tools/build_data.py` after editing. Saves use a new key, so old progress does not carry over.
- Shared engine: `@follow id` / `@follow off` (a person walks one step behind the player and comes through doors), and pause screens accept `ready` (show the button at once) and `go` (button label). The Tuesday Club was re-tested.

## 2026-10-23
- Added **Storm Over Clear Creek 青溪颱風夜** (`games/storm-creek/`), an adventure for the Community Work unit (textbook Ch. 6) on the shared story engine. You are a new community social worker in a fictional mountain village (the same Clear Creek used in the in-class worksheets). Chapter 1: find six hidden community assets (ABCD vs. NBCD). Chapter 2: on typhoon night the bridge washes out, and the village rescues Grandma Chen through an old irrigation tunnel; each obstacle is solved by an asset found in Chapter 1. Chapter 3: a town hall where students identify Rothman's three models, build a mixed plan, and use PARK. Epilogue: Lantern Night (celebrating results). 15 notebook terms and 9 checks (Chinese question, English answers). No classroom pauses, so it works solo, as homework, in pairs on one phone, or on the projector with an 8BitDo. Chapter codes (MAPS, STORM, TOWNHALL, LANTERN) let a new device jump ahead.
- Maps, terms, quizzes and the story script are generated by `games/storm-creek/tools/build_data.py`, which also checks every door and person can be reached. `make_tiles.py` draws `extra.png` (creek, bridge, tea rows) in the Kenney palette, released CC0.
- Added **Term Flip 名詞翻翻卡** (`games/term-flip/`), flashcards for exam review: English term on the front, Chinese on the back, with a prompt to explain or give an example. Decks for Ch. 1–7 plus a mixed deck (77 cards). Only English–Chinese pairs that were checked against the textbook are included. "Again" cards come back a few cards later. Phone (tap / swipe), keyboard, and 8BitDo. Links can open a deck directly, e.g. `games/term-flip/#ch6`.
- Shared engine: `@tint` now also takes `night`, `storm` (with a rain layer) and `dusk`. The D-pad and arrow keys now move between buttons on the title, quiz, notebook and end screens, and A presses the highlighted one, so a whole game (including quiz answers) can be played with an 8BitDo. The Tuesday Club was re-tested and works as before.
- Fixed the Tuesday Club's chapter label on the launch page: social group work is textbook Ch. 5, not Ch. 3.

## 2026-10-19
- Added **Term Duel** (`games/term-duel/`), a whole-class vocabulary game on each student's own phone (same format as the Death site's Term Duel). Students play rock-paper-scissors; the winner names a term, the loser gives the Chinese or a plain-English explanation, and the winner holds **Answer** to check. Ticks are saved on the phone, per topic. Two word banks from *The Tuesday Club*: **What Makes a Group** (10 terms) and **Group Stages & Social Goals** (10 terms). Links can go straight to a topic, e.g. `games/term-duel/#group-basics`. Sounds are generated in the browser.
- Set up the site: launch page (`index.html`) built from `games.json`, with a backup game list so it also opens straight from a folder. README, CHANGELOG, `.nojekyll`, and a `.gitignore` that keeps token files and the push scripts out of the repository.
- Added **The Tuesday Club 星期二俱樂部** (`games/tuesday-club/`) for the Social Group Work unit (textbook Ch. 3): a walk-around story game for groups of 4 with one phone per pair. Students follow Rosa through one girls' club at Hull House in the 1890s, from its first meeting to its goodbye, framed by Rosa looking back in 1935. Each chapter is one stage of group development: convening and formation, then conflict, then maintenance and termination. Dialogue in Traditional Chinese with 21 English key terms collected in a notebook; six chapter-check questions (Chinese question, English answers, hint and retry on a wrong answer).
- The game stops at three classroom pauses that unlock with codes on the teacher's slide. Pause 1: each group names itself and sets a goal and rules. Pause 2: the screen recaps what each character knows, and the group chooses A–D what the club leader should do; the choice changes how Chapter 3 opens. Pause 3: a spoken goodbye to a teammate. Progress is saved at the start of each chapter, and a code typed on the title screen jumps a new phone to that chapter.
- Dialogue choices appear in a panel over the map so every option is visible at once. The notebook opens from the end screen.
- Shared story engine (`games/engine/`) so later weeks can add new chapter games by writing a map and a script (`data.js`) without new code. Touch pad, keyboard and 8BitDo controller; the map scales to fill phones in portrait or landscape.
- Launch page footer: an "About these games" note on AI-assisted development (same wording as the Death site), plus a short Kenney credit.
- Pixel art: Tiny Town and Tiny Dungeon by Kenney (kenney.nl), CC0 1.0 (`assets/tiles/`, license files included). Music and sound effects are generated in the browser.
