"""Social Work Research: one-idea, large-font, bilingual SVG slides.
Run: python week11_build_svgs.py imgs   -> writes imgs/11_01_hook.svg ... and imgs/11_game_qr.png
Same look as the administration slides (1600 x 900, teal / orange, Noto Sans TC / Microsoft JhengHei).
"""

import pathlib, sys

OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "imgs")
OUT.mkdir(parents=True, exist_ok=True)

W, H = 1600, 900
TEAL, ORANGE, INK, GRAY, LIGHT, RED, GREEN, CREAM = (
    "#2c5f6f", "#d98e3a", "#1c2430", "#6b7a8c", "#e8eef0", "#c0563f", "#5aa06e", "#fbf6ea")
PURPLE, BLUE, PINK, GOLD = "#a56db0", "#4f7fc0", "#c95f8a", "#d0a02c"
FONT = "'Noto Sans TC','Noto Sans CJK TC','Microsoft JhengHei',sans-serif"
GAME_URL = "https://ncnusw.github.io/introsw/games/family-next-door/"


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def svg(body):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" '
            f'font-family="{FONT}">\n'
            '<defs><marker id="ar" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" '
            f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{TEAL}"/></marker>'
            '<marker id="arO" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" '
            f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{ORANGE}"/></marker></defs>\n'
            f'{body}\n</svg>\n')


def t(x, y, s, size=36, fill=INK, weight=400, anchor="middle", extra=""):
    return (f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}" font-weight="{weight}" '
            f'text-anchor="{anchor}" {extra}>{esc(s)}</text>')


def headline(s, sub=None, size=60):
    out = t(W / 2, 92, s, size, INK, 700)
    out += f'<rect x="{W/2-90}" y="118" width="180" height="7" rx="3" fill="{ORANGE}"/>'
    if sub:
        out += t(W / 2, 178, sub, 36, GRAY)
    return out


def chip(x, y, en, zh, color=TEAL, size=30):
    w = size * len(en) * 0.58 + size * 1.08 * len(zh) + 80
    return (f'<g><rect x="{x-w/2}" y="{y-size*1.3}" width="{w}" height="{size*1.95}" rx="{size}" fill="{color}"/>'
            + t(x, y, f"{en}　{zh}", size, "#fff", 700) + '</g>')


def box(x, y, w, h, fill=CREAM, stroke=TEAL, rx=18, sw=4, dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{d}/>'


def arrow(x1, y1, x2, y2, color=TEAL, sw=6, marker="ar"):
    return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{sw}" marker-end="url(#{marker})"/>'


def person(x, y, s=1.0, color=TEAL):
    return (f'<g transform="translate({x},{y}) scale({s})">'
            f'<circle cx="0" cy="-118" r="26" fill="{color}"/>'
            f'<path d="M-38,0 L-38,-55 Q-38,-86 0,-86 Q38,-86 38,-55 L38,0 Z" fill="{color}"/></g>')


slides = {}

# 01 HOOK -------------------------------------------------------------------------
b = headline("The family next door is struggling.", "隔壁那一家很辛苦。你會怎麼幫？")
b += f'<path d="M560,560 L800,380 L1040,560 Z" fill="{CREAM}" stroke="{TEAL}" stroke-width="6"/>'
b += box(600, 560, 400, 200, CREAM, TEAL, 6, 6)
b += person(700, 740, .9, ORANGE) + person(800, 740, .65, BLUE) + person(900, 740, .95, GRAY)
b += t(800, 805, "Mom 媽媽 · Xiao Yu 小宇 · Grandpa 阿公", 32, INK, 700)
for en, zh, x, y in [("Mom works two jobs", "媽媽做兩份工作", 280, 300), ("Xiao Yu skips school", "小宇常蹺課", 280, 480),
                     ("Grandpa keeps falling", "阿公一直跌倒", 280, 660), ("The lane is dark", "巷子路燈壞了", 1320, 360),
                     ("Trash fills the empty lot", "空地堆滿垃圾", 1320, 580)]:
    b += box(x - 230, y - 62, 460, 124, "#fff3e6", ORANGE, 62, 4)
    b += t(x, y - 8, en, 34, INK, 700) + t(x, y + 38, zh, 32, GRAY)
b += t(800, 880, "Pair talk: What would you do first? 你會先做什麼？", 38, RED, 700)
slides["11_01_hook"] = b

# 02 WAYS OF KNOWING -----------------------------------------------------------------
b = headline("Five ways we “know” without checking.", "五種沒有經過查證的「知道」 · 鈕文英 (2024)", 56)
ways = [("Intuition &", "experience", "個人直覺與經驗", "“I did it,", "so will he.”", TEAL),
        ("Authority", "", "權威人士的說法", "“The chief", "said so.”", BLUE),
        ("Tradition", "", "傳統與前例", "“We always", "do it this way.”", PURPLE),
        ("Common", "sense", "一般常識", "“Everyone", "knows that.”", ORANGE),
        ("Logic", "", "邏輯推理", "“If A, then B.”", "(Is A true?)", GREEN)]
for i, (e1, e2, zh, q1, q2, col) in enumerate(ways):
    x = 40 + i * 308
    b += box(x, 230, 290, 560, "#fff", col, 22, 6)
    b += f'<rect x="{x}" y="230" width="290" height="190" rx="22" fill="{col}"/>'
    b += t(x + 145, 300 if e2 else 320, e1, 38, "#fff", 700)
    if e2:
        b += t(x + 145, 348, e2, 38, "#fff", 700)
    b += t(x + 145, 392 if e2 else 380, "", 1)
    b += t(x + 145, 500, zh, 32 if len(zh) <= 5 else 28, col, 700)
    b += t(x + 145, 620, q1, 30, INK, 700) + t(x + 145, 665, q2, 30, INK, 700)
b += t(800, 860, "Useful every day. But none of them checks the facts.", 36, RED, 700)
slides["11_02_ways"] = b

# 03 HALO EFFECT ------------------------------------------------------------------------
b = headline("Good at one thing ≠ good at everything.")
b += f'<ellipse cx="420" cy="345" rx="80" ry="22" fill="none" stroke="{GOLD}" stroke-width="10"/>'
b += person(420, 640, 1.9, ORANGE)
b += f'<circle cx="560" cy="600" r="48" fill="{ORANGE}" stroke="{INK}" stroke-width="4"/>'
b += f'<path d="M512,600 L608,600 M560,552 L560,648" stroke="{INK}" stroke-width="3"/>'
b += t(420, 730, "A famous basketball star", 36, INK, 700) + t(420, 780, "籃球明星", 34, GRAY)
b += box(760, 230, 760, 110, "#fff", GRAY, 55, 4) + t(1140, 300, "“Drink my energy drink every day!”", 36, INK, 700)
for k, (mark, en, zh, col) in enumerate([("✔", "Basketball", "打籃球", GREEN), ("✘", "Raising children", "教養孩子", RED),
                                          ("✘", "Helping older adults", "照顧長輩", RED), ("✘", "Family problems", "家庭問題", RED)]):
    y = 420 + k * 95
    b += t(820, y, mark, 52, col, 700) + t(890, y, en, 40, INK, 700, "start") + t(1370, y, zh, 36, GRAY, 400, "start")
b += chip(800, 860, "Halo effect", "月暈效應", RED, 36)
slides["11_03_halo"] = b

# 04 EMPIRICAL ----------------------------------------------------------------------------
b = headline("Research means checking, not guessing.", "研究＝查證，不是猜測")
for i, (en, zh, col) in enumerate([("Ask a question", "提出問題", TEAL), ("Collect data", "蒐集資料", BLUE),
                                   ("Analyze data", "分析資料", PURPLE), ("Answer", "回答問題", GREEN)]):
    x = 70 + i * 380
    b += box(x, 300, 320, 220, col, col, 26, 0)
    b += t(x + 160, 400, en, 40, "#fff", 700) + t(x + 160, 460, zh, 36, "#fff", 700)
    if i < 3:
        b += arrow(x + 326, 410, x + 372, 410, ORANGE, 8, "arO")
b += t(800, 650, "Empirical = based on data we can see and count.", 40, INK, 700)
b += t(800, 710, "實證：根據看得到、數得出來的資料。", 36, GRAY)
b += chip(800, 840, "Empirical research", "實證研究", ORANGE, 36)
slides["11_04_empirical"] = b

# 05 WHY SOCIAL WORKERS NEED RESEARCH ---------------------------------------------------------
b = headline("Why do social workers need research?", "社工為什麼需要研究？")
why = [("1", "Do no harm", "不傷害", "Good intentions can hurt.", TEAL),
       ("2", "Find what works", "找到有效的方法", "Use help that is proven.", BLUE),
       ("3", "Accountability", "責信", "Show clients and funders.", ORANGE),
       ("4", "Give people a voice", "讓聲音被聽見", "Data can change policy.", GREEN)]
for i, (n, en, zh, d, col) in enumerate(why):
    x, y = 110 + (i % 2) * 720, 230 + (i // 2) * 310
    b += box(x, y, 660, 270, "#fff", col, 24, 6)
    b += f'<circle cx="{x+90}" cy="{y+135}" r="56" fill="{col}"/>' + t(x + 90, y + 158, n, 62, "#fff", 700)
    b += t(x + 175, y + 105, en, 44, INK, 700, "start") + t(x + 175, y + 160, zh, 38, col, 700, "start")
    b += t(x + 175, y + 220, d, 32, GRAY, 400, "start")
slides["11_05_why"] = b

# 06 SCARED STRAIGHT ----------------------------------------------------------------------------
b = headline("Good intentions are not enough.", "好意不等於有效")
b += box(80, 230, 680, 560, CREAM, TEAL, 24, 5)
b += t(420, 300, "Scared Straight 嚇阻從善", 40, TEAL, 700)
for k, ln in enumerate(["Teens visit a prison.", "Prisoners shout and scare them.", "Goal: stop future crime.",
                        "It looked great on TV.", "Many places copied it."]):
    b += t(120, 390 + k * 70, "• " + ln, 34, INK, 400, "start")
base = 720
for i, (lab, zh, h, col) in enumerate([("Did not go", "沒有參加", 200, GRAY), ("Went", "有參加", 300, RED)]):
    x = 900 + i * 300
    b += f'<rect x="{x}" y="{base-h}" width="200" height="{h}" rx="10" fill="{col}"/>'
    b += t(x + 100, base + 50, lab, 34, INK, 700) + t(x + 100, base + 92, zh, 30, GRAY)
b += f'<line x1="860" y1="{base}" x2="1440" y2="{base}" stroke="{INK}" stroke-width="4"/>'
b += t(1150, 300, "Later crime 之後犯罪", 36, INK, 700)
b += t(1150, 360, "Teens who went did MORE crime, not less.", 30, RED, 700)
b += t(800, 875, "Petrosino et al. (2013): a review of studies from many places. Only research could show this.", 28, GRAY)
slides["11_06_scared"] = b

# ===== CASE: ARISTOLOCHIC ACID 馬兜鈴酸 (extra-large type) =================================================
def big_head(en, zh=None, size=76):
    out = t(W / 2, 108, en, size, INK, 700)
    out += f'<rect x="{W/2-110}" y="136" width="220" height="9" rx="4" fill="{RED}"/>'
    if zh:
        out += t(W / 2, 212, zh, 50, GRAY, 700)
    return out

def herb(x, y, s=1.0, col=GREEN):
    """A simple herb sprig."""
    return (f'<g transform="translate({x},{y}) scale({s})">'
            f'<path d="M0,0 C-6,-80 6,-160 0,-240" stroke="{col}" stroke-width="10" fill="none"/>'
            + ''.join(f'<ellipse cx="{dx}" cy="{dy}" rx="44" ry="20" fill="{col}" transform="rotate({rot} {dx} {dy})"/>'
                      for dx, dy, rot in [(-40, -70, -30), (40, -110, 30), (-38, -160, -30), (36, -200, 30), (0, -250, -90)])
            + '</g>')

def bowl(x, y, s=1.0):
    return (f'<g transform="translate({x},{y}) scale({s})">'
            f'<path d="M-150,0 Q0,170 150,0 Z" fill="{CREAM}" stroke="{INK}" stroke-width="8"/>'
            f'<ellipse cx="0" cy="0" rx="150" ry="26" fill="#8a5a3c" stroke="{INK}" stroke-width="8"/>'
            + ''.join(f'<path d="M{dx},-30 q-24,-40 0,-80 q24,-40 0,-80" stroke="{GRAY}" stroke-width="7" fill="none" opacity=".7"/>' for dx in (-60, 0, 60))
            + '</g>')

# a. hook
b = big_head("Grandma's herbal tonic", "阿嬤的中藥補方")
b += bowl(420, 640, 1.3) + herb(260, 500, .9) + herb(590, 500, .8, TEAL)
b += t(880, 380, "Used for 用來：", 50, GRAY, 700, "start")
for k, (en, zh) in enumerate([("losing weight", "減肥"), ("after childbirth", "產後補身"), ("coughs", "止咳")]):
    b += t(880, 470 + k * 90, f"• {en}  {zh}", 52, INK, 700, "start")
b += f'<rect x="200" y="760" width="1200" height="110" rx="55" fill="{ORANGE}"/>'
b += t(800, 835, "Would you drink it? 你會喝嗎？", 60, "#fff", 700)
slides["11_06a_aa_hook"] = b

# b. Belgium
b = big_head("1993: a warning from Belgium", "比利時：減肥中藥與腎衰竭")
b += person(330, 700, 1.6, PINK) + person(520, 700, 1.4, PINK) + person(710, 700, 1.5, PINK)
b += t(520, 790, "young women 年輕女性", 48, INK, 700)
b += arrow(860, 520, 1000, 520, RED, 14)
b += f'<path d="M1150,360 C1040,360 1030,520 1110,560 C1030,600 1060,720 1170,700 C1290,690 1300,360 1150,360 Z" fill="{RED}" opacity=".85"/>'
b += t(1170, 800, "kidney failure", 52, RED, 700) + t(1170, 862, "腎衰竭", 50, RED, 700)
b += t(520, 862, "took a slimming herbal remedy", 40, GRAY)
slides["11_06b_aa_belgium"] = b

# c. 39%
b = big_head("How many Taiwanese took it?", "1997–2003 健保用藥資料")
b += t(560, 640, "39%", 300, RED, 700)
b += t(1180, 430, "of 200,000 people", 52, INK, 700) + t(1180, 500, "took herbs with", 52, INK, 700)
b += t(1180, 570, "aristolochic acid", 52, RED, 700)
b += t(1180, 660, "二十萬人中，39%", 46, GRAY, 700) + t(1180, 720, "吃過含馬兜鈴酸的中藥", 46, GRAY, 700)
b += t(800, 860, "Data: National Health Insurance records (王榮德, NTU)", 34, GRAY)
slides["11_06c_aa_39"] = b

# d. the study
b = big_head("More herb, more cancer.", "病例對照研究 case-control study · Lai et al. (2010)")
for i, (lab, zh, h) in enumerate([("No AA herbs", "沒吃", 150), ("Some", "少量", 290), ("> 60 g 木通", "大量", 450)]):
    x = 140 + i * 300
    b += f'<rect x="{x}" y="{780-h}" width="220" height="{h}" rx="12" fill="{[GRAY, ORANGE, RED][i]}"/>'
    b += t(x + 110, 830, lab, 38, INK, 700) + t(x + 110, 875, zh, 34, GRAY, 700)
b += f'<line x1="110" y1="780" x2="1040" y2="780" stroke="{INK}" stroke-width="6"/>'
b += t(590, 300, "risk of urinary tract cancer 泌尿道癌風險 (illustration 示意圖)", 32, GRAY, 700)
b += box(1090, 290, 450, 470, CREAM, TEAL, 24, 6)
b += t(1315, 360, "Ruled out 排除：", 44, TEAL, 700)
for k, ln in enumerate(["age 年齡", "sex 性別", "arsenic water 砷", "infections 感染"]):
    b += t(1140, 450 + k * 80, "✔ " + ln, 42, INK, 700, "start")
slides["11_06d_aa_study"] = b

# e. ban
b = big_head("2003: Taiwan bans five herbs", "2003 年 11 月 4 日 衛生署公告禁用")
for i, zh in enumerate(["廣防己", "青木香", "關木通", "馬兜鈴", "天仙藤"]):
    x = 120 + i * 280
    b += box(x, 330, 240, 300, "#fff", RED, 24, 7)
    b += herb(x + 120, 560, .55, GREEN)
    b += t(x + 120, 610, zh, 50, INK, 700)
    b += f'<line x1="{x+20}" y1="350" x2="{x+220}" y2="610" stroke="{RED}" stroke-width="12" opacity=".8"/>'
b += t(800, 760, "Research → policy 研究改變政策", 64, TEAL, 700)
slides["11_06e_aa_ban"] = b

# f. after the ban
b = big_head("After the ban, cancer kept rising...", "禁用後，癌症還在增加……直到 2010 年", 66)
x0, y0, x1 = 160, 760, 1440
b += f'<line x1="{x0}" y1="{y0}" x2="{x1}" y2="{y0}" stroke="{INK}" stroke-width="6"/>'
b += f'<path d="M{x0},700 C420,640 640,520 820,420 C930,360 990,340 1060,350 C1200,380 1300,470 {x1},540" fill="none" stroke="{RED}" stroke-width="14"/>'
for yr, x in [("1995", 160), ("2003", 640), ("2010", 1050), ("2018", 1440)]:
    b += t(x, y0 + 60, yr, 44, INK, 700)
b += f'<line x1="640" y1="300" x2="640" y2="{y0}" stroke="{TEAL}" stroke-width="6" stroke-dasharray="16 12"/>'
b += t(640, 290, "ban 禁用", 46, TEAL, 700)
b += t(1060, 300, "peak 高峰", 46, RED, 700)
b += box(150, 330, 430, 150, CREAM, ORANGE, 20, 5)
b += t(365, 395, "Why? 為什麼？", 46, ORANGE, 700) + t(365, 455, "cancer takes years", 36, INK, 700)
b += t(800, 880, "upper urinary tract cancer · illustration 示意圖 (latency 潛伏期)", 30, GRAY)
slides["11_06f_aa_after"] = b

# 07 FIVE PURPOSES --------------------------------------------------------------------------------
b = headline("Research climbs five steps.", "研究的五個目的")
steps = [("Describe", "敘述", "How many days", "did Xiao Yu miss?"), ("Explain", "解釋", "Why does he", "skip school?"),
         ("Predict", "預測", "Who might", "drop out?"), ("Intervene", "介入與處遇", "What should", "we do?"),
         ("Evaluate", "比較與評估", "Did it", "work?")]
for i, (en, zh, q1, q2) in enumerate(steps):
    x, y = 60 + i * 300, 640 - i * 90
    col = [TEAL, BLUE, PURPLE, ORANGE, GREEN][i]
    b += f'<rect x="{x}" y="{y}" width="285" height="{830 - y}" rx="14" fill="{col}"/>'
    b += t(x + 142, y + 60, en, 40, "#fff", 700) + t(x + 142, y + 108, zh, 34 if len(zh) < 4 else 30, "#fff", 700)
    b += t(x + 142, y - 70, q1, 30, col, 700) + t(x + 142, y - 30, q2, 30, col, 700)
slides["11_07_purposes"] = b

# 08 QUESTION & HYPOTHESIS ----------------------------------------------------------------------------
b = headline("Start with a good question.", "好的研究問題：清楚、能用資料回答、重要")
b += box(80, 220, 680, 300, "#fff", RED, 24, 5)
b += t(420, 290, "✘ Weak question", 40, RED, 700)
b += t(420, 380, "“Is Xiao Yu a bad kid?”", 38, INK, 700) + t(420, 440, "「小宇是不是壞孩子？」", 34, GRAY)
b += box(840, 220, 680, 300, "#fff", GREEN, 24, 5)
b += t(1180, 290, "✔ Research question", 40, GREEN, 700)
b += t(1180, 380, "“What keeps Xiao Yu", 38, INK, 700) + t(1180, 428, "from going to school?”", 38, INK, 700)
b += t(1180, 480, "「是什麼讓小宇不去上學？」", 32, GRAY)
b += box(80, 570, 1440, 230, CREAM, ORANGE, 24, 5)
b += t(800, 630, "Hypothesis 研究假設 = a prediction we can test", 40, ORANGE, 700)
b += t(800, 700, "If older adults join a weekly exercise group,", 36, INK, 700)
b += t(800, 750, "then they will fall less.", 36, INK, 700)
b += t(800, 860, "如果長輩參加每週運動團體，那麼他們會比較少跌倒。", 32, GRAY)
slides["11_08_question"] = b

# 09 DEDUCTIVE vs INDUCTIVE -----------------------------------------------------------------------------
b = headline("Two directions: test an idea, or build one.")
for i, (en, zh, top, bot, col, sub) in enumerate([
        ("Deductive", "演繹法", "Theory / hypothesis", "Data", TEAL, "often quantitative 量化"),
        ("Inductive", "歸納法", "Data", "New idea / theory", ORANGE, "often qualitative 質性")]):
    x = 400 + i * 800
    b += t(x, 230, f"{en} {zh}", 50, col, 700)
    b += box(x - 240, 290, 480, 120, col, col, 20, 0) + t(x, 365, top, 40, "#fff", 700)
    b += arrow(x, 420, x, 590, col, 10, "ar" if col == TEAL else "arO")
    b += box(x - 240, 600, 480, 120, "#fff", col, 20, 5) + t(x, 675, bot, 40, col, 700)
    b += t(x, 800, sub, 38, INK, 700)
b += f'<line x1="800" y1="200" x2="800" y2="830" stroke="{GRAY}" stroke-width="3" stroke-dasharray="10 10"/>'
slides["11_09_logic"] = b

# 10 QUANT vs QUAL ---------------------------------------------------------------------------------------
b = headline("Count it, or understand it.", "量化：算一算　質性：懂一懂")
b += box(80, 230, 680, 520, "#fff", TEAL, 24, 6)
b += f'<rect x="80" y="230" width="680" height="120" rx="24" fill="{TEAL}"/>'
b += t(420, 310, "Quantitative 量化", 46, "#fff", 700)
b += t(420, 420, "numbers · surveys · statistics", 32, GRAY)
b += t(420, 540, "5 / 5", 110, TEAL, 700)
b += t(420, 620, "households: “The lane is too dark.”", 32, INK, 700)
b += t(420, 680, "五戶都說：巷子太暗", 32, GRAY)
b += box(840, 230, 680, 520, "#fff", ORANGE, 24, 6)
b += f'<rect x="840" y="230" width="680" height="120" rx="24" fill="{ORANGE}"/>'
b += t(1180, 310, "Qualitative 質性", 46, "#fff", 700)
b += t(1180, 420, "words · interviews · observation", 32, GRAY)
b += t(1180, 520, "“I'm not lazy.", 44, ORANGE, 700) + t(1180, 580, "I'm afraid of falling.”", 44, ORANGE, 700)
b += t(1180, 660, "— Grandpa 阿公：「我不是懶，我是怕跌倒。」", 30, GRAY)
b += chip(800, 840, "Mixed methods = both", "混合研究方法", PURPLE, 34)
slides["11_10_quantqual"] = b

# 11 QUANT vs QUAL TABLE ---------------------------------------------------------------------------------
b = headline("Quantitative vs. qualitative, side by side.", size=52)
rows = [("Purpose 目的", "predict · explain", "explore · understand"),
        ("Setting 情境", "controlled", "natural"),
        ("Design 設計", "decided first", "grows step by step"),
        ("Researcher 角色", "neutral", "learner"),
        ("Method 方法", "survey, questionnaire", "interview, observation"),
        ("Process 過程", "straight line", "open, flexible")]
b += f'<rect x="440" y="160" width="540" height="80" rx="12" fill="{TEAL}"/>' + t(710, 214, "Quantitative 量化", 38, "#fff", 700)
b += f'<rect x="1000" y="160" width="560" height="80" rx="12" fill="{ORANGE}"/>' + t(1280, 214, "Qualitative 質性", 38, "#fff", 700)
for k, (d, qn, ql) in enumerate(rows):
    y = 260 + k * 102
    if k % 2 == 0:
        b += f'<rect x="40" y="{y}" width="1520" height="96" rx="8" fill="{CREAM}"/>'
    b += t(60, y + 62, d, 34, GRAY, 700, "start") + t(710, y + 62, qn, 36, INK, 700) + t(1280, y + 62, ql, 36, INK, 700)
slides["11_11_table"] = b

# 11b MIXED METHODS: WHY BOTH ---------------------------------------------------------------------------
b = headline("Mixed methods: numbers + stories.", "混合研究方法：數字＋故事")
b += box(70, 220, 600, 400, "#fff", TEAL, 24, 6)
b += f'<rect x="70" y="220" width="600" height="100" rx="24" fill="{TEAL}"/>' + t(370, 285, "Quantitative 量化", 40, "#fff", 700)
b += t(370, 420, "3 / 5", 100, TEAL, 700)
b += t(370, 500, "households: kids have", 32, INK, 700) + t(370, 545, "nowhere to go after school", 32, INK, 700)
b += t(370, 595, "tells us HOW MANY 有多少", 30, TEAL, 700)
b += t(800, 440, "+", 110, GRAY, 700)
b += box(930, 220, 600, 400, "#fff", ORANGE, 24, 6)
b += f'<rect x="930" y="220" width="600" height="100" rx="24" fill="{ORANGE}"/>' + t(1230, 285, "Qualitative 質性", 40, "#fff", 700)
b += t(1230, 400, "“Nobody's home,", 40, ORANGE, 700) + t(1230, 455, "and I can't ask", 40, ORANGE, 700) + t(1230, 510, "anyone about math.”", 40, ORANGE, 700)
b += t(1230, 595, "tells us WHY 為什麼", 30, ORANGE, 700)
b += box(170, 670, 1260, 140, CREAM, PURPLE, 24, 5)
b += t(800, 728, "Together: a fuller, more trustworthy picture.", 40, PURPLE, 700)
b += t(800, 782, "兩種資料互相補充、互相檢驗，看得更完整、更可信。", 32, GRAY)
b += t(800, 870, "Creswell & Plano Clark (2018)", 28, GRAY)
slides["11_11b_mixed_why"] = b

# 11c MIXED METHODS: THREE DESIGNS ---------------------------------------------------------------------
b = headline("Three ways to mix.", "三種常見的混合研究設計 · Creswell & Plano Clark (2018)", 56)
def mbox(x, y, w, label, col, solid=True, hgt=76):
    fill, tc = (col, "#fff") if solid else ("#fff", col)
    return box(x, y, w, hgt, fill, col, 16, 5) + t(x + w / 2, y + hgt / 2 + 12, label, 34, tc, 700)
designs = [
    ("Convergent", "聚斂式：同時做，再比較", "Survey + interviews at once, then compare.",
     lambda y: mbox(760, y + 8, 250, "QUAN 量化", TEAL, hgt=68) + mbox(760, y + 96, 250, "QUAL 質性", ORANGE, False, 68)
     + arrow(1018, y + 42, 1150, y + 82, INK, 5) + arrow(1018, y + 130, 1150, y + 96, INK, 5) + mbox(1160, y + 52, 300, "Compare 比較", PURPLE)),
    ("Explanatory", "解釋性：先算，再問為什麼", "3/5 say \u201cnowhere to go\u201d \u2192 interviews ask why.",
     lambda y: mbox(760, y + 52, 250, "QUAN 量化", TEAL) + arrow(1018, y + 90, 1150, y + 90, INK, 6) + mbox(1160, y + 52, 300, "QUAL 質性", ORANGE, False)),
    ("Exploratory", "探索性：先聽，再算多少人", "Interviews find themes \u2192 a survey for everyone.",
     lambda y: mbox(760, y + 52, 250, "QUAL 質性", ORANGE, False) + arrow(1018, y + 90, 1150, y + 90, INK, 6) + mbox(1160, y + 52, 300, "QUAN 量化", TEAL)),
]
for i, (en, zh, ex, draw) in enumerate(designs):
    y = 220 + i * 222
    if i % 2 == 0:
        b += f'<rect x="30" y="{y}" width="1540" height="206" rx="16" fill="{CREAM}"/>'
    b += t(60, y + 70, en, 44, INK, 700, "start") + t(60, y + 120, zh, 32, GRAY, 700, "start")
    b += t(60, y + 172, ex, 28, GRAY, 400, "start")
    b += draw(y)
slides["11_11c_mixed_designs"] = b

# 12 SIX STEPS -------------------------------------------------------------------------------------------
b = headline("Six steps from a question to a report.", "研究的六個步驟")
st6 = [("Choose a question", "選定研究問題", "What keeps Yu home?"), ("Review literature", "檢閱文獻", "What do studies say?"),
       ("Design the study", "提出研究設計", "Survey + interviews"), ("Collect data", "蒐集資料", "Ask every household"),
       ("Analyze data", "分析資料", "Count and find themes"), ("Write the report", "撰寫研究報告", "Share with city + lane")]
for i, (en, zh, ex) in enumerate(st6):
    col = [TEAL, BLUE, PURPLE, ORANGE, GREEN, PINK][i]
    x, y = 60 + (i % 3) * 500, 230 + (i // 3) * 310
    b += box(x, y, 460, 270, "#fff", col, 22, 6)
    b += f'<circle cx="{x+68}" cy="{y+70}" r="46" fill="{col}"/>' + t(x + 68, y + 90, str(i + 1), 54, "#fff", 700)
    b += t(x + 130, y + 72, en, 34, INK, 700, "start")
    b += t(x + 230, y + 160, zh, 38, col, 700)
    b += t(x + 230, y + 225, ex, 28, GRAY)
slides["11_12_steps"] = b

# 13 ETHICS ---------------------------------------------------------------------------------------------
b = headline("Research is done with people, so it has rules.", "研究倫理", 54)
eth = [("Voluntary", "自願參與", "Say yes or no.|Stop any time.", TEAL),
       ("Informed consent", "知情同意", "Explain first,|then ask.", BLUE),
       ("Confidentiality", "保密", "No names,|no faces.", PURPLE),
       ("Do no harm", "不傷害", "Nobody leaves|worse off.", GREEN)]
for i, (en, zh, d, col) in enumerate(eth):
    x = 50 + i * 380
    b += box(x, 230, 350, 520, "#fff", col, 24, 6)
    b += f'<rect x="{x}" y="230" width="350" height="170" rx="24" fill="{col}"/>'
    b += t(x + 175, 300, en, 36 if len(en) < 12 else 32, "#fff", 700) + t(x + 175, 360, zh, 38, "#fff", 700)
    for k, w in enumerate(d.split("|")):
        b += t(x + 175, 530 + k * 66, w, 38, INK, 700)
b += t(800, 840, "✘ Secret recording · ✘ Posting a family's story online", 36, RED, 700)
slides["11_13_ethics"] = b

# 14 EBP --------------------------------------------------------------------------------------------------
b = headline("Evidence-based practice: three circles.", "實證為基礎的實務 · Sackett et al. (2000)", 54)
for cx, cy, col in [(640, 430, TEAL), (960, 430, ORANGE), (800, 640, GREEN)]:
    b += f'<circle cx="{cx}" cy="{cy}" r="210" fill="{col}" opacity=".55"/>'
for cx, cy, en1, en2, zh in [(520, 360, "Best research", "evidence", "最佳研究證據"), (1080, 360, "Worker's", "expertise", "社工的專業經驗"),
                             (800, 740, "Client's values", "& preferences", "案主的價值與偏好")]:
    b += t(cx, cy, en1, 34, INK, 700) + t(cx, cy + 42, en2, 34, INK, 700) + t(cx, cy + 88, zh, 30, INK, 700)
b += f'<circle cx="800" cy="510" r="62" fill="#fff" stroke="{INK}" stroke-width="4"/>' + t(800, 524, "EBP", 40, INK, 700)
b += t(120, 560, "Studies say", 30, TEAL, 700, "start") + t(120, 600, "exercise prevents falls.", 30, TEAL, 700, "start")
b += t(1480, 560, "Grandpa loves", 30, GREEN, 700, "end") + t(1480, 600, "gardening and chess.", 30, GREEN, 700, "end")
slides["11_14_ebp"] = b

# 15 DID IT WORK? ------------------------------------------------------------------------------------------
b = headline("Did it work? Compare.", "成效評估：比較組")
base = 720
groups = [("Peace Lane", "和平巷 (program 有方案)", [(4, GRAY), (0.4, GREEN)]), ("Bright Lane", "光明巷 (no program 沒有方案)", [(4, GRAY), (3.8, GRAY)])]
for g, (en, zh, bars) in enumerate(groups):
    x0 = 160 + g * 700
    for k, (v, col) in enumerate(bars):
        x, h = x0 + k * 220, v * 95
        b += f'<rect x="{x}" y="{base-h}" width="170" height="{h}" rx="10" fill="{col}"/>'
        b += t(x + 85, base + 45, ["Before 之前", "After 之後"][k], 30, INK, 700)
    b += t(x0 + 195, 230, en, 40, INK, 700) + t(x0 + 195, 275, zh, 30, GRAY)
    b += f'<line x1="{x0-20}" y1="{base}" x2="{x0+410}" y2="{base}" stroke="{INK}" stroke-width="4"/>'
b += t(800, 815, "Falls among older adults (every 6 months) 長輩跌倒次數", 32, GRAY)
b += t(800, 875, "Output 產出 = 48 sessions held · Outcome 成效 = fewer falls", 36, ORANGE, 700)
slides["11_15_compare"] = b

# ===== CASE: AI AND MATH (PNAS 2025, extra-large type) =================================================
b = big_head("AI helped practice... then hurt the test.", "AI 讓練習變好，卻讓考試變差", 64)
groups = [("Practice with AI", "有 AI 練習", [("+48%", 48, ORANGE), ("+127%", 127, TEAL)]),
          ("Exam without AI", "沒有 AI 的考試", [("−17%", -17, ORANGE), ("≈ 0", 0.5, TEAL)])]
base = 650
b += f'<line x1="120" y1="{base}" x2="1480" y2="{base}" stroke="{INK}" stroke-width="6"/>'
for g, (en, zh, bars) in enumerate(groups):
    gx = 200 + g * 700
    for k, (lab, v, col) in enumerate(bars):
        x = gx + k * 260
        hgt = abs(v) * 1.9
        y = base - hgt if v > 0 else base
        b += f'<rect x="{x}" y="{y}" width="200" height="{max(hgt, 8)}" rx="10" fill="{col}"/>'
        b += t(x + 100, (y - 24) if v > 0 else (base + hgt + 70), lab, 60, col, 700)
    b += t(gx + 230, 848, en, 44, INK, 700) + t(gx + 230, 893, zh, 34, GRAY, 700)
b += f'<rect x="1080" y="240" width="40" height="40" rx="6" fill="{ORANGE}"/>' + t(1135, 275, "plain ChatGPT 直接給答案", 32, INK, 700, "start")
b += f'<rect x="1080" y="300" width="40" height="40" rx="6" fill="{TEAL}"/>' + t(1135, 335, "AI tutor (hints) 只給提示", 32, INK, 700, "start")
b += t(1080, 400, "~1,000 high school students", 30, GRAY, 700, "start") + t(1080, 440, "Turkey · randomized 隨機分派", 30, GRAY, 700, "start")
slides["11_15b_ai_math"] = b

b = big_head("Answers vs. hints", "給答案，還是給提示？")
b += box(80, 260, 680, 480, "#fff", ORANGE, 30, 8)
b += t(420, 360, "Gives answers", 60, ORANGE, 700) + t(420, 430, "直接給答案", 50, ORANGE, 700)
b += t(420, 580, "−17%", 130, ORANGE, 700) + t(420, 680, "on the real test", 40, GRAY, 700)
b += box(840, 260, 680, 480, "#fff", TEAL, 30, 8)
b += t(1180, 360, "Gives hints", 60, TEAL, 700) + t(1180, 430, "只給提示、問問題", 50, TEAL, 700)
b += t(1180, 580, "no harm", 110, TEAL, 700) + t(1180, 680, "students still learned", 40, GRAY, 700)
b += t(800, 840, "Bastani et al. (2025), PNAS · Tool design matters 工具設計很重要", 34, GRAY, 700)
slides["11_15c_ai_hints"] = b

# 16 EVERY SOCIAL WORKER -------------------------------------------------------------------------------------
b = headline("Every social worker uses research.", "每一位社工都在用研究")
lv = [("Micro 個人", "Track one client's progress", "追蹤個案的進展", TEAL),
      ("Mezzo 團體", "Check if a group helped", "評估團體有沒有幫助", ORANGE),
      ("Macro 社區與政策", "Needs assessment, policy", "需求評量、倡議政策", GREEN)]
for i, (lvl, en, zh, col) in enumerate(lv):
    y = 240 + i * 200
    b += f'<rect x="100" y="{y}" width="460" height="160" rx="80" fill="{col}"/>' + t(330, y + 98, lvl, 42, "#fff", 700)
    b += t(620, y + 70, en, 42, INK, 700, "start") + t(620, y + 125, zh, 36, GRAY, 400, "start")
b += t(800, 860, "You don't need a lab coat. You need good questions and honest data.", 34, TEAL, 700)
slides["11_16_everyday"] = b

# 17 RECAP --------------------------------------------------------------------------------------------------
b = headline("Guess less. Check more. Help better.", "少猜一點，多查證，幫得更好")
for i, (en, zh, col) in enumerate([("Guess", "猜", GRAY), ("Check", "查證", TEAL), ("Help", "幫助", ORANGE)]):
    x = 160 + i * 480
    b += f'<circle cx="{x+120}" cy="460" r="150" fill="{col}"/>'
    b += t(x + 120, 450, en, 54, "#fff", 700) + t(x + 120, 515, zh, 46, "#fff", 700)
    if i < 2:
        b += arrow(x + 285, 460, x + 440, 460, INK, 8)
b += t(800, 720, "question → literature → design → data → analysis → report", 36, INK, 700)
b += t(800, 780, "+ ethics 倫理 + EBP 實證為基礎的實務", 36, GRAY)
slides["11_17_recap"] = b

for name, body in slides.items():
    (OUT / f"{name}.svg").write_text(svg(body), encoding="utf-8")

try:
    import qrcode
    qrcode.make(GAME_URL, box_size=12, border=2).save(OUT / "11_game_qr.png")
except ImportError:
    print("pip install qrcode  (to make imgs/11_game_qr.png)")
print(len(slides), "svgs ->", OUT)
